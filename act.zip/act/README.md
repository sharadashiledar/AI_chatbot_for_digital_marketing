# 🚀 PromoVista AI — Complete Marketing Campaign Platform
> **Hackathon Competition Edition** • Concept: *"ONE PRODUCT → COMPLETE AI MARKETING CAMPAIGN"*

---

## 🏆 Project Vision & 10-Second Pitch

Most AI marketing tools act as generic chatbots requiring multiple disconnected prompts for each content format. **PromoVista** eliminates all duplicate effort by introducing a unified generative marketing pipeline:

```
PRODUCT IDEA 
  ↓ 
AUDIENCE ANALYSIS 
  ↓ 
CAMPAIGN STRATEGY 
  ↓ 
ADVERTISEMENT 
  ↓ 
SOCIAL MEDIA 
  ↓ 
PRODUCT DESCRIPTION 
  ↓ 
PLATFORM ADAPTATION 
  ↓ 
CAMPAIGN KIT
```

**Judges understand the value in 10 seconds:** Enter a single product proposition once, and PromoVista instantly synthesizes an executive strategy, high-converting ad copy, a realistic Instagram preview card, an e-commerce product description, multi-platform adaptations, and a downloadable campaign dossier.

---

## ⚡ 60-Second Demo Guide (For Presenters & Judges)

1. **Launch the Demo:**
   - Click the pulsing **`⚡ 60s Live Demo`** button in the top navigation or hero section.
   - The preset for **FreshBite Cold Coffee** (`Beverage`, `College Students`, `20% student discount`, `Young & Exciting`) automatically populates into the unified form.

2. **Watch the Step-by-Step AI Processing Animation:**
   - Click **`Generate Complete Campaign`**.
   - Watch the animated 7-step pipeline:
     - `Analyzing product...`
     - `Understanding audience...`
     - `Creating marketing strategy...`
     - `Writing advertisement...`
     - `Creating social media content...`
     - `Optimizing product description...`
     - `Generating campaign ideas...`
     - `Campaign Ready! ✨`

3. **Explore the Campaign Dashboard:**
   - **AI Campaign Score:** View the `94/100` score with the explicit label: *"AI content quality indicator"*.
   - **Result Cards:**
     - **📢 1. Advertisement:** Headline ("Beat the Heat. Sip the Energy."), Body, and CTA ("Grab Your 20% Student Discount Today!").
     - **📷 2. Instagram Post:** Realistic Instagram card with interactive like counter, tags, and hashtags.
     - **🛍️ 3. Product Description:** E-commerce format with features, benefits, and instant checkout CTA.
     - **🗺️ 4. Campaign Strategy:** Executive blueprint with multi-phase cadence.
   - **Content Variations:** Switch between `A — Professional`, `B — Creative & Viral`, and `C — High-Converting`.
   - **Platform Adaptation:** Click `Instagram`, `Facebook`, `LinkedIn`, or `WhatsApp` to see instant contextual adaptation.
   - **AI Improve Dropdown:** Click `✨ Improve` on any card to make it shorter, more persuasive, urgent, or emotional.
   - **Live AI Co-Pilot:** Open the chat drawer and click `"Make the advertisement more exciting"` or `"Create a WhatsApp broadcast version"`. Click **`Apply to Campaign`** to watch the chat directly update the dashboard card in real time!
   - **Before / After Showcase:** Scroll to *"From Basic Idea → Marketing-Ready Content"* and click **`Transform with PromoVista`**.
   - **Download Kit:** Click **`Download Campaign Kit`** to export Markdown, JSON, or Print/PDF.
   - **Presentation Mode:** Press **`P`** or click **`🖥️ Present`** to toggle full-screen projector mode.

---

## 🛠️ How to Run Locally

### Option 1: Direct File Opening (No Server Required)
Simply double-click `index.html` in Windows Explorer or open it in any browser (Chrome, Edge, Firefox).

### Option 2: Run Built-In Node.js Server
Open PowerShell in this directory and run:
```bash
node server.js
```
Then visit:
```
http://localhost:3000
```

---

## 📋 Comprehensive Feature Checklist

| # | Feature | Status | Details |
|---|---|:---:|---|
| **1** | **Hero Experience** | ✅ | Headline, subheading, primary & secondary CTAs, animated 6-node pipeline |
| **2** | **Create Campaign Mode** | ✅ | Single unified form asking once for product, category, audience, features, benefits, offer, tone, goal |
| **3** | **AI Campaign Generation** | ✅ | Sequential 7-step visual animation culminating in "Campaign Ready!" |
| **4** | **Campaign Dashboard** | ✅ | Campaign title, AI Score with explicit "AI content quality indicator" label |
| **5** | **Advertisement Card** | ✅ | Headline, body, CTA, copy, edit, regenerate, improve |
| **6** | **Social Media Post** | ✅ | Realistic Instagram card with avatar, product art, interactive like counter, hashtags |
| **7** | **Product Description** | ✅ | E-commerce layout with features, benefits, audience fit, offer, and CTA |
| **8** | **Campaign Strategy (WOW)** | ✅ | Campaign name, objective, target audience, key message, platforms, 3-phase cadence, CTA |
| **9** | **Content Variations** | ✅ | 3 switchable variations: A (Professional), B (Creative), C (High-Converting) |
| **10** | **Platform Adaptation** | ✅ | Instant adaptation for Instagram, Facebook, LinkedIn, WhatsApp |
| **11** | **AI Improve Feature** | ✅ | Dropdown modifying content: shorter, persuasive, professional, emotion, urgency, simplify, emojis, CTA |
| **12** | **Live Chat Assistant** | ✅ | Context-aware Co-Pilot with active campaign sync, quick prompt chips, and "Apply to Campaign" buttons |
| **13** | **Content Quality Panel** | ✅ | Clarity, Engagement, CTA Strength, Readability bars + 1-click optimization suggestions |
| **14** | **Before / After Feature** | ✅ | Side-by-side demonstration converting basic idea into marketing suite with +340% lift |
| **15** | **Campaign Kit** | ✅ | Download full campaign kit as Markdown (.md), JSON (.json), or Print / PDF |
| **16** | **Demo Mode** | ✅ | "Launch 60-Second Demo" button pre-filling FreshBite Cold Coffee with zero typing |
| **17** | **Zero-Failure Engine** | ✅ | Local deterministic fallback engine; never displays "API Error", shows "Demo AI Mode" badge |
| **18** | **Visual Design** | ✅ | Deep blue, indigo, purple palette, glassmorphism, soft shadows, modern typography |
| **19** | **Presentation Mode** | ✅ | Hotkey 'P' / button activates projector-friendly layout with large typography and clean cards |
| **20** | **Judge-Friendly UI** | ✅ | Instant access to campaign creation, zero account signup required |
| **21** | **Full Functionality** | ✅ | All buttons functional: Copy, Edit, Save, Favorite, History, Regenerate, Improve, Download, Theme |
| **22** | **Final Polish** | ✅ | Zero lorem ipsum, real persuasive copy, mobile responsive, loading states, toasts |
| **23** | **Workflow Identity** | ✅ | Positioned as an "AI Marketing Workflow Platform" rather than a generic chatbot |

---

## 🎯 Architecture & Technologies
- **Frontend Core:** Pure HTML5, Semantic CSS3 (Glassmorphism & Projector Variables), Vanilla JavaScript (ES6+ Modules)
- **Styling Framework:** Tailwind CSS with custom theme extensions
- **Icons:** Lucide Icons (SVG)
- **Storage:** LocalStorage persistence for saved portfolios, history, and theme settings
- **Server:** Zero-dependency Node.js HTTP server (`server.js`)
- **Reliability:** 100% resilient offline generation engine with contextual intent parsing
