/**
 * PromoVista Storage Manager
 * Handles persistent state, campaign history, saved favorites,
 * user preferences, and export formats.
 */

(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.PromoVistaStorage = factory();
  }
})(typeof self !== 'undefined' ? self : this, function () {

  const STORAGE_KEYS = {
    SAVED_CAMPAIGNS: 'promovista_saved_campaigns',
    CAMPAIGN_HISTORY: 'promovista_history',
    THEME: 'promovista_theme',
    LAST_CAMPAIGN: 'promovista_active_campaign'
  };

  class StorageManager {
    constructor() {
      this.initDefaultStorage();
    }

    initDefaultStorage() {
      if (!this.getSavedCampaigns().length) {
        // Seed initial sample campaign for instant exploration
        const seed = {
          id: 'camp-freshbite-demo',
          createdAt: new Date().toISOString(),
          isFavorite: true,
          product: "FreshBite Cold Coffee",
          category: "Beverage",
          audience: "College Students (aged 18–25)",
          features: "Creamy, chilled, affordable",
          benefits: "Refreshing and energizing",
          offer: "20% student discount",
          tone: "Young & Exciting",
          goal: "Increase student sales",
          score: 94,
          strategy: {
            campaignName: "Chill Your Study Break",
            objective: "Increase student purchases and brand awareness on campus.",
            targetAudience: "College students aged 18–25 balancing exam pressure.",
            keyMessage: "Beat the heat and fuel your focus with handcrafted cold coffee.",
            suggestedPlatforms: ["Instagram", "WhatsApp", "Facebook", "Campus Posters"],
            contentStrategy: [
              "Phase 1: Relatable study fatigue reels featuring iced coffee swirl.",
              "Phase 2: Campus ambassador promo code drops offering 20% off.",
              "Phase 3: Tag your study buddy giveaway contests."
            ],
            callToAction: "Grab Your 20% Student Discount Today!"
          },
          ad: {
            headline: "Beat the Heat. Sip the Energy.",
            body: "Crush mid-semester fatigue with the smoothest, ice-chilled brew in town. Slow-steeped for 16 hours with creamy velvety richness.",
            cta: "Grab Your 20% Student Discount Today!"
          },
          social: {
            brandName: "FreshBite Café",
            caption: "Your college break just got colder! ☕❄️\n\nCreamy. Chilled. Delicious.\n\nStudents get 20% OFF today!\n\nTag your study buddy 👇",
            hashtags: ["#FreshBite", "#ColdCoffee", "#StudentOffer", "#CollegeLife", "#CafeVibes"]
          },
          description: {
            title: "FreshBite Signature Cold Brew Blend",
            overview: "FreshBite Cold Coffee is an artisan, slow-steeped beverage crafted specifically for students and young creators.",
            cta: "Add to Order • Pick Up in 5 Minutes"
          }
        };
        this.saveCampaign(seed);
      }
    }

    getSavedCampaigns() {
      try {
        const raw = localStorage.getItem(STORAGE_KEYS.SAVED_CAMPAIGNS);
        return raw ? JSON.parse(raw) : [];
      } catch (e) {
        console.warn("Storage read error:", e);
        return [];
      }
    }

    saveCampaign(campaign) {
      try {
        const list = this.getSavedCampaigns();
        const existingIndex = list.findIndex(c => c.id === campaign.id || c.product === campaign.product);
        if (existingIndex >= 0) {
          list[existingIndex] = { ...list[existingIndex], ...campaign, updatedAt: new Date().toISOString() };
        } else {
          list.unshift({ ...campaign, id: campaign.id || 'camp-' + Date.now(), savedAt: new Date().toISOString() });
        }
        localStorage.setItem(STORAGE_KEYS.SAVED_CAMPAIGNS, JSON.stringify(list));
        return true;
      } catch (e) {
        console.error("Storage save error:", e);
        return false;
      }
    }

    toggleFavorite(campaignId) {
      const list = this.getSavedCampaigns();
      const item = list.find(c => c.id === campaignId);
      if (item) {
        item.isFavorite = !item.isFavorite;
        localStorage.setItem(STORAGE_KEYS.SAVED_CAMPAIGNS, JSON.stringify(list));
        return item.isFavorite;
      }
      return false;
    }

    deleteCampaign(campaignId) {
      const list = this.getSavedCampaigns().filter(c => c.id !== campaignId);
      localStorage.setItem(STORAGE_KEYS.SAVED_CAMPAIGNS, JSON.stringify(list));
      return list;
    }

    addToHistory(campaign) {
      try {
        const raw = localStorage.getItem(STORAGE_KEYS.CAMPAIGN_HISTORY);
        const history = raw ? JSON.parse(raw) : [];
        history.unshift({
          id: 'hist-' + Date.now(),
          product: campaign.product,
          score: campaign.score || 92,
          timestamp: new Date().toISOString(),
          campaign: campaign
        });
        // Limit history to 15 items
        const trimmed = history.slice(0, 15);
        localStorage.setItem(STORAGE_KEYS.CAMPAIGN_HISTORY, JSON.stringify(trimmed));
      } catch (e) {
        console.warn("History save error:", e);
      }
    }

    getHistory() {
      try {
        const raw = localStorage.getItem(STORAGE_KEYS.CAMPAIGN_HISTORY);
        return raw ? JSON.parse(raw) : [];
      } catch (e) {
        return [];
      }
    }

    getTheme() {
      return localStorage.getItem(STORAGE_KEYS.THEME) || 'dark';
    }

    setTheme(theme) {
      localStorage.setItem(STORAGE_KEYS.THEME, theme);
    }
  }

  return new StorageManager();
});
