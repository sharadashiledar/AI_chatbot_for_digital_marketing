/**
 * PromoVista Main Application Controller
 * Handles UI interactions, animated generation pipeline,
 * card actions, platform adaptation, variation toggles,
 * chat drawer, and presentation mode.
 */

document.addEventListener('DOMContentLoaded', () => {
  // Initialize Core Engines
  const engine = window.PromoVistaEngine;
  const storage = window.PromoVistaStorage;
  const chatAssistant = new window.PromoVistaChat(engine, {
    onApply: (target, data) => applyChatContentToCard(target, data)
  });

  // State
  let currentCampaign = null;
  let activeVariation = 'creative'; // 'professional' | 'creative' | 'highConverting'
  let activePlatform = 'instagram';  // 'instagram' | 'facebook' | 'linkedin' | 'whatsapp'
  let isGenerating = false;
  let isPresentationMode = false;

  // DOM Elements Cache
  const form = document.getElementById('campaign-form');
  const btnGenerate = document.getElementById('btn-generate');
  const btnHeroCreate = document.getElementById('hero-btn-create');
  const btnHeroDemo = document.getElementById('hero-btn-demo');
  const btnQuickDemo = document.getElementById('nav-btn-demo');
  const generationModal = document.getElementById('generation-modal');
  const generationSteps = document.getElementById('generation-steps');
  const resultsSection = document.getElementById('results-section');
  const heroSection = document.getElementById('hero-section');
  const beforeAfterSection = document.getElementById('before-after-section');
  const chatDrawer = document.getElementById('chat-drawer');
  const chatMessagesContainer = document.getElementById('chat-messages');
  const chatInput = document.getElementById('chat-input');
  const chatSendBtn = document.getElementById('chat-send-btn');
  const savedModal = document.getElementById('saved-campaigns-modal');

  // Load Saved Theme
  const savedTheme = storage.getTheme();
  document.documentElement.setAttribute('data-theme', savedTheme);
  updateThemeIcon(savedTheme);

  // Initialize Icons
  if (window.lucide) {
    window.lucide.createIcons();
  }

  // --- INITIALIZATION ---
  initEventListeners();
  initPresetButtons();
  initBeforeAfterDemo();
  renderChatHistory();

  // If a saved campaign exists in storage, prime it for instant readiness
  const initialSaved = storage.getSavedCampaigns();
  if (initialSaved.length > 0) {
    currentCampaign = initialSaved[0];
    chatAssistant.setCampaignContext(currentCampaign);
    renderCampaignDashboard(currentCampaign);
  }

  // --- EVENT LISTENERS ---
  function initEventListeners() {
    // Hero CTAs
    if (btnHeroCreate) {
      btnHeroCreate.addEventListener('click', () => {
        document.getElementById('create-section').scrollIntoView({ behavior: 'smooth' });
      });
    }

    if (btnHeroDemo) {
      btnHeroDemo.addEventListener('click', () => {
        loadPresetAndGenerate('freshbite');
      });
    }

    if (btnQuickDemo) {
      btnQuickDemo.addEventListener('click', () => {
        loadPresetAndGenerate('freshbite');
      });
    }

    // Form Submit
    if (form) {
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        triggerCampaignGeneration();
      });
    }

    // Theme Toggle
    const themeBtn = document.getElementById('theme-toggle');
    if (themeBtn) {
      themeBtn.addEventListener('click', toggleTheme);
    }

    // Presentation Mode Toggle
    const presentBtn = document.getElementById('btn-presentation-mode');
    const exitPresentBtn = document.getElementById('btn-exit-presentation');
    if (presentBtn) presentBtn.addEventListener('click', togglePresentationMode);
    if (exitPresentBtn) exitPresentBtn.addEventListener('click', togglePresentationMode);

    // Keyboard shortcut 'P' for Presentation Mode, 'Esc' to exit
    document.addEventListener('keydown', (e) => {
      if (e.key === 'p' || e.key === 'P') {
        if (!['INPUT', 'TEXTAREA'].includes(document.activeElement.tagName)) {
          togglePresentationMode();
        }
      }
      if (e.key === 'Escape' && isPresentationMode) {
        togglePresentationMode();
      }
    });

    // Chat Drawer Toggle
    const chatToggleBtns = document.querySelectorAll('.toggle-chat-btn');
    chatToggleBtns.forEach(btn => {
      btn.addEventListener('click', toggleChatDrawer);
    });

    const chatCloseBtn = document.getElementById('chat-close-btn');
    if (chatCloseBtn) {
      chatCloseBtn.addEventListener('click', () => {
        chatDrawer.classList.add('translate-x-full');
      });
    }

    // Chat Send
    if (chatSendBtn && chatInput) {
      chatSendBtn.addEventListener('click', handleChatSubmit);
      chatInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
          e.preventDefault();
          handleChatSubmit();
        }
      });
    }

    // Saved Campaigns Modal Toggle
    const savedToggleBtns = document.querySelectorAll('.toggle-saved-btn');
    savedToggleBtns.forEach(btn => {
      btn.addEventListener('click', openSavedCampaignsModal);
    });

    const closeSavedBtn = document.getElementById('close-saved-modal');
    if (closeSavedBtn) {
      closeSavedBtn.addEventListener('click', () => {
        savedModal.classList.add('hidden');
      });
    }

    // Global Kit Download
    const btnDownloadKit = document.getElementById('btn-download-kit');
    if (btnDownloadKit) {
      btnDownloadKit.addEventListener('click', showDownloadKitModal);
    }

    // Global Save Campaign
    const btnSaveCampaign = document.getElementById('btn-save-campaign');
    if (btnSaveCampaign) {
      btnSaveCampaign.addEventListener('click', () => {
        if (!currentCampaign) return;
        storage.saveCampaign(currentCampaign);
        showToast("Campaign saved to your local portfolio! 📁");
      });
    }

    // Variations Switcher (Requirement 9)
    const variationBtns = document.querySelectorAll('[data-variation]');
    variationBtns.forEach(btn => {
      btn.addEventListener('click', (e) => {
        const v = e.currentTarget.getAttribute('data-variation');
        switchVariation(v);
      });
    });

    // Platform Adaptation Switcher (Requirement 10)
    const platformBtns = document.querySelectorAll('[data-platform]');
    platformBtns.forEach(btn => {
      btn.addEventListener('click', (e) => {
        const p = e.currentTarget.getAttribute('data-platform');
        switchPlatform(p);
      });
    });

    // Social Post Interactive Likes
    const igLikeBtn = document.getElementById('ig-like-btn');
    if (igLikeBtn) {
      igLikeBtn.addEventListener('click', () => {
        const heart = igLikeBtn.querySelector('i');
        const countSpan = document.getElementById('ig-like-count');
        const isLiked = igLikeBtn.classList.toggle('text-red-500');
        let count = parseInt(countSpan.getAttribute('data-count') || '428', 10);
        count = isLiked ? count + 1 : count - 1;
        countSpan.textContent = count.toLocaleString() + ' likes';
        countSpan.setAttribute('data-count', count);
      });
    }
  }

  // --- PRESET LOADER (Requirement 2 & 16) ---
  function initPresetButtons() {
    const presetBtns = document.querySelectorAll('[data-preset]');
    presetBtns.forEach(btn => {
      btn.addEventListener('click', (e) => {
        const presetKey = e.currentTarget.getAttribute('data-preset');
        loadPresetIntoForm(presetKey);
        showToast(`Loaded preset: ${engine.DEMO_PRESETS[presetKey].name} ⚡`);
      });
    });
  }

  function loadPresetIntoForm(presetKey) {
    const p = engine.DEMO_PRESETS[presetKey];
    if (!p) return;

    document.getElementById('input-name').value = p.name;
    document.getElementById('input-category').value = p.category;
    document.getElementById('input-audience').value = p.audience;
    document.getElementById('input-features').value = p.features;
    document.getElementById('input-benefits').value = p.benefits;
    document.getElementById('input-offer').value = p.offer;
    document.getElementById('input-tone').value = p.tone;
    document.getElementById('input-goal').value = p.goal;
  }

  function loadPresetAndGenerate(presetKey) {
    loadPresetIntoForm(presetKey);
    document.getElementById('create-section').scrollIntoView({ behavior: 'smooth' });
    setTimeout(() => {
      triggerCampaignGeneration();
    }, 400);
  }

  // --- GENERATION PIPELINE (Requirement 3) ---
  async function triggerCampaignGeneration() {
    if (isGenerating) return;
    isGenerating = true;

    const params = {
      name: document.getElementById('input-name').value,
      category: document.getElementById('input-category').value,
      audience: document.getElementById('input-audience').value,
      features: document.getElementById('input-features').value,
      benefits: document.getElementById('input-benefits').value,
      offer: document.getElementById('input-offer').value,
      tone: document.getElementById('input-tone').value,
      goal: document.getElementById('input-goal').value
    };

    // Open Modal Animation
    generationModal.classList.remove('hidden');
    generationModal.classList.add('flex');

    const steps = [
      "Analyzing product proposition and features...",
      "Understanding target audience psychographics...",
      "Creating multi-channel marketing strategy...",
      "Writing high-converting advertisement copy...",
      "Creating Instagram social media content...",
      "Optimizing e-commerce product description...",
      "Generating viral campaign ideas & platform adaptations...",
      "Campaign Ready! ✨"
    ];

    const stepElements = steps.map((text, idx) => {
      return `
        <div id="gen-step-${idx}" class="step-item flex items-center gap-3 text-sm py-2 px-3 rounded-lg border border-transparent">
          <div class="step-icon w-6 h-6 rounded-full flex items-center justify-center bg-slate-800 text-slate-400 text-xs font-semibold">
            ${idx + 1}
          </div>
          <span class="step-text text-slate-300 font-medium">${text}</span>
          <span class="step-status ml-auto text-xs text-indigo-400 font-mono"></span>
        </div>
      `;
    }).join('');

    generationSteps.innerHTML = stepElements;

    // Simulate animated step progression (each step ~300ms for responsiveness yet tangible AI feel)
    for (let i = 0; i < steps.length; i++) {
      const stepEl = document.getElementById(`gen-step-${i}`);
      if (!stepEl) continue;

      stepEl.classList.add('active');
      stepEl.classList.remove('opacity-40');
      const icon = stepEl.querySelector('.step-icon');
      const status = stepEl.querySelector('.step-status');

      if (i < steps.length - 1) {
        icon.innerHTML = `<svg class="animate-spin h-3.5 w-3.5 text-indigo-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>`;
        status.textContent = "Processing...";
        await delay(320);

        icon.innerHTML = `✓`;
        icon.classList.remove('bg-slate-800', 'text-slate-400');
        icon.classList.add('bg-emerald-500/20', 'text-emerald-400', 'border', 'border-emerald-500/40');
        status.textContent = "Done";
        status.classList.remove('text-indigo-400');
        status.classList.add('text-emerald-400');
        stepEl.classList.remove('active');
        stepEl.classList.add('completed');
      } else {
        // Final step
        icon.innerHTML = `🎉`;
        icon.classList.add('bg-indigo-500/30', 'text-indigo-300');
        status.textContent = "Ready!";
        status.classList.add('text-indigo-400', 'font-bold');
        await delay(400);
      }
    }

    // Generate Campaign Data
    const campaign = await engine.generateCompleteCampaign(params);
    currentCampaign = campaign;
    storage.saveCampaign(campaign);
    storage.addToHistory(campaign);
    chatAssistant.setCampaignContext(campaign);

    // Close Modal and Show Results
    await delay(300);
    generationModal.classList.add('hidden');
    generationModal.classList.remove('flex');
    isGenerating = false;

    renderCampaignDashboard(campaign);
    resultsSection.classList.remove('hidden');
    resultsSection.scrollIntoView({ behavior: 'smooth' });

    showToast("🎉 Campaign successfully generated!");
    if (window.lucide) window.lucide.createIcons();
  }

  // --- RENDER RESULTS DASHBOARD (Requirements 4, 5, 6, 7, 8, 13) ---
  function renderCampaignDashboard(campaign) {
    if (!campaign) return;

    // Header Info
    document.getElementById('res-campaign-name').textContent = campaign.strategy.campaignName;
    document.getElementById('res-product-name').textContent = campaign.product;
    document.getElementById('res-category-badge').textContent = campaign.category;
    document.getElementById('res-tone-badge').textContent = campaign.tone;

    // AI Quality Score & Label (Requirement 4)
    document.getElementById('res-score-value').textContent = `${campaign.score}/100`;

    // 1. Advertisement Card (Requirement 5)
    document.getElementById('ad-headline').textContent = campaign.ad.headline;
    document.getElementById('ad-subheadline').textContent = campaign.ad.subheadline || '';
    document.getElementById('ad-body').textContent = campaign.ad.body;
    document.getElementById('ad-cta-btn').textContent = campaign.ad.cta;
    document.getElementById('ad-urgency').textContent = campaign.ad.urgencyNote || '';

    // 2. Social Media Post (Instagram Mockup) (Requirement 6)
    document.getElementById('ig-brand-name').textContent = campaign.social.brandName;
    document.getElementById('ig-handle').textContent = campaign.social.handle || '@' + campaign.product.toLowerCase().replace(/\s+/g, '');
    document.getElementById('ig-location').textContent = campaign.social.locationTag || 'Campus Central Hub';
    document.getElementById('ig-caption').innerHTML = formatTextWithLinebreaks(campaign.social.caption);
    document.getElementById('ig-hashtags').textContent = campaign.social.hashtags.join(' ');
    document.getElementById('ig-mockup-product-name').textContent = campaign.product;
    document.getElementById('ig-mockup-offer').textContent = campaign.offer || '20% OFF';

    // 3. Product Description (E-Commerce Style) (Requirement 7)
    document.getElementById('prod-title').textContent = campaign.description.title;
    document.getElementById('prod-tagline').textContent = campaign.description.tagline;
    document.getElementById('prod-overview').textContent = campaign.description.overview;
    document.getElementById('prod-target-fit').textContent = campaign.description.targetAudienceFit;
    document.getElementById('prod-offer-callout').textContent = campaign.description.offerCallout;
    document.getElementById('prod-cta-btn').textContent = campaign.description.cta;

    // Features List
    const featContainer = document.getElementById('prod-features-list');
    if (featContainer && campaign.description.keyFeatures) {
      featContainer.innerHTML = campaign.description.keyFeatures.map(f => `
        <div class="flex items-start gap-2.5 text-xs text-slate-300">
          <div class="w-4 h-4 rounded-full bg-indigo-500/20 text-indigo-400 flex items-center justify-center shrink-0 mt-0.5">✓</div>
          <div>
            <strong class="text-white">${f.title}:</strong>
            <span class="text-slate-400">${f.detail}</span>
          </div>
        </div>
      `).join('');
    }

    // 4. Campaign Strategy (Requirement 8 - WOW Feature)
    document.getElementById('strat-name').textContent = campaign.strategy.campaignName;
    document.getElementById('strat-objective').textContent = campaign.strategy.objective;
    document.getElementById('strat-audience').textContent = campaign.strategy.targetAudience;
    document.getElementById('strat-key-message').textContent = campaign.strategy.keyMessage;
    document.getElementById('strat-cta').textContent = campaign.strategy.callToAction;

    // Suggested Platforms
    const platformsContainer = document.getElementById('strat-platforms-list');
    if (platformsContainer && campaign.strategy.suggestedPlatforms) {
      platformsContainer.innerHTML = campaign.strategy.suggestedPlatforms.map(p => `
        <span class="px-2.5 py-1 rounded-full text-xs font-medium bg-indigo-500/10 border border-indigo-500/30 text-indigo-300 flex items-center gap-1.5">
          <span class="w-1.5 h-1.5 rounded-full bg-indigo-400"></span>${p}
        </span>
      `).join('');
    }

    // Content Strategy Cadence
    const cadenceContainer = document.getElementById('strat-cadence-list');
    if (cadenceContainer && campaign.strategy.contentStrategy) {
      cadenceContainer.innerHTML = campaign.strategy.contentStrategy.map((step, idx) => `
        <li class="flex items-start gap-3 text-xs text-slate-300">
          <span class="w-5 h-5 rounded-md bg-purple-500/20 text-purple-300 flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">${idx + 1}</span>
          <span>${step}</span>
        </li>
      `).join('');
    }

    // 5. Content Quality Panel (Requirement 13)
    renderQualityPanel(campaign.qualityAnalysis);

    // Bind Card Interactive Buttons (View, Edit, Copy, Regenerate, Improve)
    bindCardActions();
    if (window.lucide) window.lucide.createIcons();
  }

  // --- CONTENT QUALITY PANEL (Requirement 13) ---
  function renderQualityPanel(qa) {
    if (!qa) return;
    const metricsContainer = document.getElementById('quality-metrics-container');
    if (metricsContainer && qa.metrics) {
      metricsContainer.innerHTML = qa.metrics.map(m => `
        <div class="space-y-1">
          <div class="flex justify-between text-xs">
            <span class="text-slate-300 font-medium">${m.name}</span>
            <span class="text-indigo-400 font-mono font-bold">${m.score}/100</span>
          </div>
          <div class="w-full bg-slate-800/80 rounded-full h-2 overflow-hidden border border-slate-700/50">
            <div class="bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-500 h-2 rounded-full transition-all duration-1000" style="width: ${m.score}%"></div>
          </div>
          <p class="text-[11px] text-slate-400 leading-tight">${m.desc}</p>
        </div>
      `).join('');
    }

    // Actionable Suggestions
    const suggestionsContainer = document.getElementById('quality-suggestions-container');
    if (suggestionsContainer && qa.suggestions) {
      suggestionsContainer.innerHTML = qa.suggestions.map(s => `
        <div class="flex items-center justify-between p-2 rounded-lg bg-indigo-950/30 border border-indigo-800/30 text-xs">
          <span class="text-slate-300 pr-2">💡 ${s.text}</span>
          <button class="px-2.5 py-1 bg-indigo-600 hover:bg-indigo-500 text-white rounded text-[11px] font-semibold shrink-0 transition" data-fix-action="${s.actionType}">
            Fix Now
          </button>
        </div>
      `).join('');

      suggestionsContainer.querySelectorAll('[data-fix-action]').forEach(btn => {
        btn.addEventListener('click', (e) => {
          const action = e.currentTarget.getAttribute('data-fix-action');
          applyImprovement('ad', action);
        });
      });
    }
  }

  // --- BIND CARD ACTIONS (View, Edit, Copy, Regenerate, Improve) (Requirements 4, 11, 21) ---
  function bindCardActions() {
    // 1. Copy Buttons
    document.querySelectorAll('[data-copy-target]').forEach(btn => {
      btn.onclick = (e) => {
        const target = e.currentTarget.getAttribute('data-copy-target');
        copyCardContent(target);
      };
    });

    // 2. Edit Buttons
    document.querySelectorAll('[data-edit-target]').forEach(btn => {
      btn.onclick = (e) => {
        const target = e.currentTarget.getAttribute('data-edit-target');
        openEditModal(target);
      };
    });

    // 3. View / Expand Buttons
    document.querySelectorAll('[data-view-target]').forEach(btn => {
      btn.onclick = (e) => {
        const target = e.currentTarget.getAttribute('data-view-target');
        openViewModal(target);
      };
    });

    // 4. Regenerate Buttons
    document.querySelectorAll('[data-regen-target]').forEach(btn => {
      btn.onclick = (e) => {
        const target = e.currentTarget.getAttribute('data-regen-target');
        regenerateSpecificCard(target);
      };
    });

    // 5. Improve Dropdowns (Requirement 11)
    document.querySelectorAll('.ai-improve-toggle').forEach(btn => {
      btn.onclick = (e) => {
        e.stopPropagation();
        const menu = e.currentTarget.nextElementSibling;
        document.querySelectorAll('.ai-dropdown-menu').forEach(m => {
          if (m !== menu) m.classList.remove('show');
        });
        menu.classList.toggle('show');
      };
    });

    // Close dropdowns on outer click
    document.addEventListener('click', () => {
      document.querySelectorAll('.ai-dropdown-menu').forEach(m => m.classList.remove('show'));
    });

    // Improve Action Items
    document.querySelectorAll('[data-improve-action]').forEach(item => {
      item.onclick = (e) => {
        const action = e.currentTarget.getAttribute('data-improve-action');
        const cardTarget = e.currentTarget.closest('[data-card-wrapper]').getAttribute('data-card-wrapper');
        applyImprovement(cardTarget, action);
      };
    });
  }

  // --- CARD COPY ACTION ---
  function copyCardContent(target) {
    if (!currentCampaign) return;
    let textToCopy = "";

    switch (target) {
      case 'ad':
        textToCopy = `HEADLINE: ${currentCampaign.ad.headline}\nSUBHEADLINE: ${currentCampaign.ad.subheadline || ''}\nBODY:\n${currentCampaign.ad.body}\nCTA: ${currentCampaign.ad.cta}`;
        break;
      case 'social':
        textToCopy = `${currentCampaign.social.caption}\n\n${currentCampaign.social.hashtags.join(' ')}`;
        break;
      case 'description':
        textToCopy = `${currentCampaign.description.title}\n${currentCampaign.description.tagline}\n\n${currentCampaign.description.overview}\n\nOFFER: ${currentCampaign.description.offerCallout}\nCTA: ${currentCampaign.description.cta}`;
        break;
      case 'strategy':
        textToCopy = `CAMPAIGN: ${currentCampaign.strategy.campaignName}\nOBJECTIVE: ${currentCampaign.strategy.objective}\nAUDIENCE: ${currentCampaign.strategy.targetAudience}\nKEY MESSAGE: ${currentCampaign.strategy.keyMessage}\nCTA: ${currentCampaign.strategy.callToAction}`;
        break;
    }

    navigator.clipboard.writeText(textToCopy).then(() => {
      showToast(`Copied ${target.toUpperCase()} to clipboard! 📋`);
    }).catch(() => {
      showToast("Unable to copy to clipboard automatically.");
    });
  }

  // --- EDIT MODAL ---
  function openEditModal(target) {
    if (!currentCampaign) return;
    const modal = document.getElementById('edit-content-modal');
    const textarea = document.getElementById('edit-modal-textarea');
    const title = document.getElementById('edit-modal-title');
    const saveBtn = document.getElementById('edit-modal-save');

    title.textContent = `Edit ${target.toUpperCase()} Content`;

    let initialValue = "";
    if (target === 'ad') initialValue = currentCampaign.ad.body;
    else if (target === 'social') initialValue = currentCampaign.social.caption;
    else if (target === 'description') initialValue = currentCampaign.description.overview;
    else if (target === 'strategy') initialValue = currentCampaign.strategy.keyMessage;

    textarea.value = initialValue;
    modal.classList.remove('hidden');
    modal.classList.add('flex');

    saveBtn.onclick = () => {
      const updated = textarea.value.trim();
      if (target === 'ad') currentCampaign.ad.body = updated;
      else if (target === 'social') currentCampaign.social.caption = updated;
      else if (target === 'description') currentCampaign.description.overview = updated;
      else if (target === 'strategy') currentCampaign.strategy.keyMessage = updated;

      renderCampaignDashboard(currentCampaign);
      modal.classList.add('hidden');
      modal.classList.remove('flex');
      showToast("Content updated successfully! ✏️");
    };

    document.getElementById('edit-modal-cancel').onclick = () => {
      modal.classList.add('hidden');
      modal.classList.remove('flex');
    };
  }

  // --- VIEW / EXPAND MODAL ---
  function openViewModal(target) {
    if (!currentCampaign) return;
    const modal = document.getElementById('view-content-modal');
    const modalBody = document.getElementById('view-modal-content');
    const modalTitle = document.getElementById('view-modal-title');

    modalTitle.textContent = `${target.toUpperCase()} Detailed View`;

    if (target === 'ad') {
      modalBody.innerHTML = `
        <div class="space-y-4">
          <div class="border-b border-slate-700 pb-3">
            <span class="text-xs uppercase tracking-wider text-indigo-400 font-bold">Headline</span>
            <h3 class="text-xl font-bold text-white mt-1">${currentCampaign.ad.headline}</h3>
          </div>
          <div>
            <span class="text-xs uppercase tracking-wider text-slate-400 font-bold">Body Copy</span>
            <p class="text-slate-200 mt-1 leading-relaxed">${currentCampaign.ad.body}</p>
          </div>
          <div class="pt-3 border-t border-slate-700">
            <span class="text-xs uppercase tracking-wider text-emerald-400 font-bold">Call To Action</span>
            <div class="mt-1 font-semibold text-white bg-indigo-600/30 p-2.5 rounded-lg border border-indigo-500/30">${currentCampaign.ad.cta}</div>
          </div>
        </div>
      `;
    } else if (target === 'social') {
      modalBody.innerHTML = `
        <div class="space-y-4">
          <div class="p-4 rounded-xl bg-slate-900 border border-slate-700">
            <div class="font-bold text-white mb-2">${currentCampaign.social.brandName} (${currentCampaign.social.handle})</div>
            <div class="text-slate-200 whitespace-pre-line leading-relaxed text-sm">${currentCampaign.social.caption}</div>
            <div class="mt-3 text-xs text-indigo-400 font-medium">${currentCampaign.social.hashtags.join(' ')}</div>
          </div>
        </div>
      `;
    } else if (target === 'description') {
      modalBody.innerHTML = `
        <div class="space-y-3">
          <h3 class="text-lg font-bold text-white">${currentCampaign.description.title}</h3>
          <p class="text-xs text-indigo-300 italic">${currentCampaign.description.tagline}</p>
          <p class="text-slate-300 leading-relaxed text-sm">${currentCampaign.description.overview}</p>
          <div class="p-3 bg-indigo-950/40 border border-indigo-800/40 rounded-lg text-xs text-emerald-300">
            ${currentCampaign.description.offerCallout}
          </div>
        </div>
      `;
    } else if (target === 'strategy') {
      modalBody.innerHTML = `
        <div class="space-y-3 text-sm">
          <div><strong class="text-indigo-400">Campaign:</strong> ${currentCampaign.strategy.campaignName}</div>
          <div><strong class="text-indigo-400">Objective:</strong> ${currentCampaign.strategy.objective}</div>
          <div><strong class="text-indigo-400">Audience:</strong> ${currentCampaign.strategy.targetAudience}</div>
          <div><strong class="text-indigo-400">Core Message:</strong> ${currentCampaign.strategy.keyMessage}</div>
          <div><strong class="text-indigo-400">Call to Action:</strong> ${currentCampaign.strategy.callToAction}</div>
        </div>
      `;
    }

    modal.classList.remove('hidden');
    modal.classList.add('flex');

    document.getElementById('view-modal-close').onclick = () => {
      modal.classList.add('hidden');
      modal.classList.remove('flex');
    };
  }

  // --- REGENERATE SPECIFIC CARD ---
  function regenerateSpecificCard(target) {
    if (!currentCampaign) return;

    if (target === 'ad') {
      const variations = [
        { headline: "Fuel Your Potential with FreshBite.", body: "Specially slow-extracted for students who demand supreme focus and silky-smooth taste without crashing before finals.", cta: "Unlock Your 20% Discount Today!" },
        { headline: "The Secret to All-Night Study Stamina.", body: "16 hours of artisanal cold extraction condensed into one frosty, creamy cup. Say goodbye to bitter cafeteria coffee forever.", cta: "Claim Your Student Cold Brew Now!" },
        { headline: "Beat the Heat. Sip the Energy.", body: "Crush mid-semester fatigue with the creamiest, ice-chilled brew in town. Slow-steeped for 16 hours with velvety richness.", cta: "Grab Your 20% Student Discount Today!" }
      ];
      const randomAd = variations[Math.floor(Math.random() * variations.length)];
      currentCampaign.ad = { ...currentCampaign.ad, ...randomAd };
      showToast("Regenerated Advertisement copy! 🔄");
    } else if (target === 'social') {
      const altCaptions = [
        `When your lecture ends but your study grind doesn't... ☕❄️\n\nFreshBite Cold Coffee is the ultimate cold-brew lifeline.\n\nStudents grab 20% OFF today!\n\nTag someone who needs iced coffee right now! 👇`,
        `Your study session deserves better than burnt drip coffee! 🥶✨\n\nCreamy, slow-steeped, and ice-cold.\n\nFlash your student ID for 20% OFF all day!\n\nWho are you bringing along? 🏃💨`
      ];
      currentCampaign.social.caption = altCaptions[Math.floor(Math.random() * altCaptions.length)];
      showToast("Regenerated Instagram post! 📱");
    } else if (target === 'description') {
      currentCampaign.description.overview = `Crafted for discerning creators, ${currentCampaign.product} combines artisanal preparation with pure, sustained energy. Each batch is micro-brewed to eliminate bitterness and elevate satisfaction.`;
      showToast("Regenerated Product Description! 🛍️");
    } else if (target === 'strategy') {
      currentCampaign.strategy.campaignName = "Power Your Semester 2026";
      currentCampaign.strategy.keyMessage = `Affordable, premium refreshment to sustain high academic performance.`;
      showToast("Regenerated Campaign Strategy! 🗺️");
    }

    renderCampaignDashboard(currentCampaign);
  }

  // --- AI IMPROVEMENT OPERATOR (Requirement 11) ---
  function applyImprovement(cardTarget, improvementType) {
    if (!currentCampaign) return;

    let targetText = "";
    if (cardTarget === 'ad') targetText = currentCampaign.ad.body;
    else if (cardTarget === 'social') targetText = currentCampaign.social.caption;
    else if (cardTarget === 'description') targetText = currentCampaign.description.overview;

    const improved = engine.improveContent(targetText, improvementType);

    if (cardTarget === 'ad') currentCampaign.ad.body = improved;
    else if (cardTarget === 'social') currentCampaign.social.caption = improved;
    else if (cardTarget === 'description') currentCampaign.description.overview = improved;

    renderCampaignDashboard(currentCampaign);
    showToast(`AI Improvement Applied: "${improvementType}" ✨`);
  }

  // --- VARIATION SWITCHER (Requirement 9) ---
  function switchVariation(variantKey) {
    if (!currentCampaign || !currentCampaign.variations) return;
    activeVariation = variantKey;

    // Update active tab buttons
    document.querySelectorAll('[data-variation]').forEach(btn => {
      const match = btn.getAttribute('data-variation') === variantKey;
      btn.classList.toggle('bg-indigo-600', match);
      btn.classList.toggle('text-white', match);
      btn.classList.toggle('border-indigo-500', match);
      btn.classList.toggle('bg-slate-800/60', !match);
      btn.classList.toggle('text-slate-300', !match);
    });

    const vData = currentCampaign.variations[variantKey];
    if (vData) {
      currentCampaign.ad.headline = vData.headline;
      currentCampaign.ad.body = vData.body;
      if (vData.socialPost) {
        currentCampaign.social.caption = vData.socialPost;
      }
      renderCampaignDashboard(currentCampaign);
      showToast(`Switched to: ${vData.variantName} ✨`);
    }
  }

  // --- PLATFORM ADAPTATION SWITCHER (Requirement 10) ---
  function switchPlatform(platformKey) {
    if (!currentCampaign || !currentCampaign.platformAdaptations) return;
    activePlatform = platformKey;

    // Update active platform buttons
    document.querySelectorAll('[data-platform]').forEach(btn => {
      const match = btn.getAttribute('data-platform') === platformKey;
      btn.classList.toggle('ring-2', match);
      btn.classList.toggle('ring-indigo-400', match);
      btn.classList.toggle('scale-105', match);
    });

    const pData = currentCampaign.platformAdaptations[platformKey];
    if (pData) {
      const platformCard = document.getElementById('platform-adaptation-display');
      if (platformCard) {
        document.getElementById('platform-display-title').textContent = `${pData.platform} Adaptation`;
        document.getElementById('platform-display-format').textContent = pData.formatName;
        document.getElementById('platform-display-body').textContent = pData.content;
      }
      showToast(`Adapted campaign for ${pData.platform}! 🚀`);
    }
  }

  // --- BEFORE / AFTER DEMO (Requirement 14) ---
  function initBeforeAfterDemo() {
    const btnTransform = document.getElementById('btn-transform-before-after');
    const compData = engine.getBeforeAfterComparison();

    if (btnTransform) {
      btnTransform.addEventListener('click', () => {
        const afterPanel = document.getElementById('ba-after-panel');
        const indicator = document.getElementById('ba-lift-indicator');

        btnTransform.innerHTML = `
          <svg class="animate-spin -ml-1 mr-2 h-4 w-4 text-white inline" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
          Transforming with PromoVista AI...
        `;
        btnTransform.disabled = true;

        setTimeout(() => {
          afterPanel.classList.remove('opacity-50', 'blur-[2px]');
          indicator.classList.remove('hidden');
          btnTransform.innerHTML = `✓ Transformed into Multi-Channel Suite!`;
          btnTransform.classList.remove('from-indigo-600', 'to-purple-600');
          btnTransform.classList.add('bg-emerald-600');
          showToast("Before/After Transformation Complete! ⚡");
        }, 600);
      });
    }
  }

  // --- CAMPAIGN KIT DOWNLOAD (Requirement 15) ---
  function showDownloadKitModal() {
    if (!currentCampaign) return;
    const modal = document.getElementById('download-kit-modal');
    modal.classList.remove('hidden');
    modal.classList.add('flex');

    document.getElementById('btn-download-markdown').onclick = () => {
      downloadCampaignAsMarkdown();
      modal.classList.add('hidden');
      modal.classList.remove('flex');
    };

    document.getElementById('btn-download-json').onclick = () => {
      downloadCampaignAsJSON();
      modal.classList.add('hidden');
      modal.classList.remove('flex');
    };

    document.getElementById('btn-download-print').onclick = () => {
      modal.classList.add('hidden');
      modal.classList.remove('flex');
      window.print();
    };

    document.getElementById('close-kit-modal').onclick = () => {
      modal.classList.add('hidden');
      modal.classList.remove('flex');
    };
  }

  function downloadCampaignAsMarkdown() {
    const c = currentCampaign;
    const md = `# PromoVista AI Campaign Kit: ${c.product}
Generated: ${new Date().toLocaleDateString()} | Quality Indicator: ${c.score}/100

==================================================
1. CAMPAIGN STRATEGY
==================================================
Campaign Name: ${c.strategy.campaignName}
Objective: ${c.strategy.objective}
Target Audience: ${c.strategy.targetAudience}
Key Message: ${c.strategy.keyMessage}
Suggested Platforms: ${c.strategy.suggestedPlatforms.join(', ')}
Call To Action: ${c.strategy.callToAction}

Content Cadence:
${c.strategy.contentStrategy.map((s, i) => `${i + 1}. ${s}`).join('\n')}

==================================================
2. ADVERTISEMENT
==================================================
Headline: ${c.ad.headline}
Subheadline: ${c.ad.subheadline || ''}
Body:
${c.ad.body}

Call To Action: ${c.ad.cta}

==================================================
3. INSTAGRAM SOCIAL MEDIA POST
==================================================
Brand: ${c.social.brandName} (${c.social.handle || ''})
Caption:
${c.social.caption}

Hashtags:
${c.social.hashtags.join(' ')}

==================================================
4. PRODUCT DESCRIPTION
==================================================
Title: ${c.description.title}
Tagline: ${c.description.tagline}
Overview:
${c.description.overview}

Offer: ${c.description.offerCallout}
CTA: ${c.description.cta}

==================================================
PromoVista AI — "One Product → Complete AI Marketing Campaign"
`;

    triggerFileDownload(`${c.product.toLowerCase().replace(/\s+/g, '_')}_campaign_kit.md`, md, 'text/markdown');
    showToast("Downloaded Markdown Campaign Kit! 📄");
  }

  function downloadCampaignAsJSON() {
    const jsonStr = JSON.stringify(currentCampaign, null, 2);
    triggerFileDownload(`${currentCampaign.product.toLowerCase().replace(/\s+/g, '_')}_campaign.json`, jsonStr, 'application/json');
    showToast("Downloaded JSON Campaign Kit! 💾");
  }

  function triggerFileDownload(filename, text, mimeType) {
    const blob = new Blob([text], { type: mimeType });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  // --- PRESENTATION MODE (Requirement 19) ---
  function togglePresentationMode() {
    isPresentationMode = !isPresentationMode;
    document.body.classList.toggle('presentation-mode', isPresentationMode);

    const banner = document.getElementById('presentation-banner');
    if (banner) {
      banner.classList.toggle('hidden', !isPresentationMode);
    }

    if (isPresentationMode) {
      showToast("Entered Presentation Mode (Press 'P' or 'Esc' to exit) 🖥️");
      window.scrollTo({ top: resultsSection.offsetTop - 40, behavior: 'smooth' });
    } else {
      showToast("Exited Presentation Mode");
    }
  }

  // --- LIVE CHAT ASSISTANT (Requirement 12) ---
  function toggleChatDrawer() {
    chatDrawer.classList.toggle('translate-x-full');
    if (!chatDrawer.classList.contains('translate-x-full')) {
      chatInput.focus();
    }
  }

  async function handleChatSubmit() {
    const text = chatInput.value.trim();
    if (!text) return;
    chatInput.value = '';

    // Render user message immediately
    renderChatMessage({
      sender: 'user',
      text: text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    });

    // Process with AI Chat Assistant
    const aiResp = await chatAssistant.processUserMessage(text);
    renderChatMessage(aiResp);
  }

  function renderChatHistory() {
    chatMessagesContainer.innerHTML = '';
    chatAssistant.messages.forEach(msg => renderChatMessage(msg));
  }

  function renderChatMessage(msg) {
    const isUser = msg.sender === 'user';
    const isSystem = msg.sender === 'system';

    const div = document.createElement('div');
    div.className = `flex flex-col ${isUser ? 'items-end' : 'items-start'} gap-1 text-sm`;

    if (isSystem) {
      div.innerHTML = `
        <div class="px-3 py-1.5 rounded-lg bg-indigo-950/40 border border-indigo-800/30 text-indigo-300 text-xs text-center w-full">
          ⚡ ${msg.text}
        </div>
      `;
    } else {
      let applyButtonHtml = '';
      if (msg.appliable) {
        applyButtonHtml = `
          <button class="mt-2.5 px-3 py-1.5 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white rounded-md text-xs font-semibold flex items-center gap-1.5 shadow-sm transition" data-chat-apply='${JSON.stringify(msg.appliable)}'>
            <span>✨</span> ${msg.appliable.label}
          </button>
        `;
      }

      let quickChipsHtml = '';
      if (msg.quickActions && msg.quickActions.length) {
        quickChipsHtml = `
          <div class="flex flex-wrap gap-1.5 mt-2.5">
            ${msg.quickActions.map(qa => `
              <button class="px-2.5 py-1 rounded-full text-[11px] bg-slate-800 hover:bg-indigo-900/60 border border-indigo-500/20 text-indigo-300 transition" data-quick-prompt="${qa}">
                ${qa}
              </button>
            `).join('')}
          </div>
        `;
      }

      div.innerHTML = `
        <div class="max-w-[88%] p-3 rounded-2xl ${isUser ? 'bg-indigo-600 text-white rounded-br-xs' : 'bg-slate-800/90 border border-slate-700/60 text-slate-200 rounded-bl-xs'}">
          <div class="leading-relaxed whitespace-pre-line">${markedLikeFormat(msg.text)}</div>
          ${applyButtonHtml}
          ${quickChipsHtml}
        </div>
        <span class="text-[10px] text-slate-400 px-1">${msg.timestamp || ''}</span>
      `;
    }

    chatMessagesContainer.appendChild(div);
    chatMessagesContainer.scrollTop = chatMessagesContainer.scrollHeight;

    // Bind Apply Button
    const applyBtn = div.querySelector('[data-chat-apply]');
    if (applyBtn) {
      applyBtn.onclick = () => {
        const payload = JSON.parse(applyBtn.getAttribute('data-chat-apply'));
        applyChatContentToCard(payload.target, payload.data);
      };
    }

    // Bind Quick Chips
    div.querySelectorAll('[data-quick-prompt]').forEach(chip => {
      chip.onclick = (e) => {
        const prompt = e.currentTarget.getAttribute('data-quick-prompt');
        chatInput.value = prompt;
        handleChatSubmit();
      };
    });
  }

  function applyChatContentToCard(target, data) {
    if (!currentCampaign) return;

    if (target === 'ad') {
      currentCampaign.ad.headline = data.headline;
      currentCampaign.ad.body = data.body;
      currentCampaign.ad.cta = data.cta;
      showToast("Applied revised advertisement from chat to dashboard! ✨");
    } else if (target === 'social') {
      currentCampaign.social.caption = data.caption;
      if (data.hashtags) currentCampaign.social.hashtags = data.hashtags;
      showToast("Updated social post card from chat! 📱");
    } else if (target === 'hashtags') {
      currentCampaign.social.hashtags = data;
      showToast("Updated social media hashtags! 🏷️");
    } else if (target === 'description') {
      currentCampaign.description.overview = data.overview;
      showToast("Updated product description from chat! 🛍️");
    }

    renderCampaignDashboard(currentCampaign);
  }

  // --- SAVED CAMPAIGNS MODAL ---
  function openSavedCampaignsModal() {
    const list = storage.getSavedCampaigns();
    const container = document.getElementById('saved-campaigns-list');

    if (!list.length) {
      container.innerHTML = `<div class="text-center py-8 text-slate-400">No saved campaigns yet. Click "Save Campaign" on any generated kit!</div>`;
    } else {
      container.innerHTML = list.map(c => `
        <div class="p-3.5 rounded-xl bg-slate-800/80 border border-slate-700 flex items-center justify-between hover:border-indigo-500/50 transition">
          <div>
            <div class="font-bold text-white">${c.product}</div>
            <div class="text-xs text-indigo-300">${c.category} · Score: ${c.score}/100</div>
          </div>
          <div class="flex items-center gap-2">
            <button class="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded text-xs font-semibold" data-load-saved="${c.id || c.product}">
              Load
            </button>
            <button class="px-2 py-1.5 text-slate-400 hover:text-red-400 text-xs" data-delete-saved="${c.id || c.product}">
              🗑️
            </button>
          </div>
        </div>
      `).join('');

      container.querySelectorAll('[data-load-saved]').forEach(btn => {
        btn.onclick = (e) => {
          const id = e.currentTarget.getAttribute('data-load-saved');
          const found = list.find(x => x.id === id || x.product === id);
          if (found) {
            currentCampaign = found;
            renderCampaignDashboard(found);
            savedModal.classList.add('hidden');
            resultsSection.classList.remove('hidden');
            resultsSection.scrollIntoView({ behavior: 'smooth' });
            showToast(`Loaded saved campaign: ${found.product} 📁`);
          }
        };
      });

      container.querySelectorAll('[data-delete-saved]').forEach(btn => {
        btn.onclick = (e) => {
          const id = e.currentTarget.getAttribute('data-delete-saved');
          storage.deleteCampaign(id);
          openSavedCampaignsModal();
          showToast("Campaign removed.");
        };
      });
    }

    savedModal.classList.remove('hidden');
    savedModal.classList.add('flex');
  }

  // --- THEME SWITCHER ---
  function toggleTheme() {
    const current = document.documentElement.getAttribute('data-theme') || 'dark';
    const next = current === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', next);
    storage.setTheme(next);
    updateThemeIcon(next);
  }

  function updateThemeIcon(theme) {
    const iconContainer = document.getElementById('theme-icon-container');
    if (iconContainer) {
      iconContainer.innerHTML = theme === 'dark' ? '☀️' : '🌙';
    }
  }

  // --- TOAST NOTIFICATION SYSTEM (Requirement 22) ---
  function showToast(message) {
    let container = document.getElementById('toast-container');
    if (!container) {
      container = document.createElement('div');
      container.id = 'toast-container';
      document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = 'toast-msg';
    toast.innerHTML = `<span>${message}</span>`;
    container.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(10px)';
      toast.style.transition = 'all 0.25s ease';
      setTimeout(() => toast.remove(), 250);
    }, 2800);
  }

  // --- HELPER UTILITIES ---
  function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  function formatTextWithLinebreaks(text) {
    if (!text) return '';
    return text.replace(/\n/g, '<br/>');
  }

  function markedLikeFormat(text) {
    if (!text) return '';
    return text
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.*?)\*/g, '<em>$1</em>')
      .replace(/`([^`]+)`/g, '<code class="px-1 py-0.5 rounded bg-slate-900 text-indigo-300 font-mono text-xs">$1</code>');
  }
});
