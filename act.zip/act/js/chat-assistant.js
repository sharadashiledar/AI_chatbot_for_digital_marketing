/**
 * PromoVista Live Chat Marketing Co-Pilot
 * Context-aware AI assistant capable of analyzing, refining, and generating
 * marketing content directly tied to the active campaign.
 */

(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.PromoVistaChat = factory();
  }
})(typeof self !== 'undefined' ? self : this, function () {

  class MarketingChatAssistant {
    constructor(engine, options = {}) {
      this.engine = engine;
      this.currentCampaign = null;
      this.messages = [];
      this.onApplyCallback = options.onApply || null;
      this.initDefaultMessages();
    }

    setCampaignContext(campaign) {
      this.currentCampaign = campaign;
      this.messages.push({
        id: 'ctx-' + Date.now(),
        sender: 'system',
        text: `Active Campaign synchronized: "${campaign.product}" (${campaign.category}) for ${campaign.audience}. Ready for real-time copy refinement, platform variations, and strategy inquiries.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      });
    }

    initDefaultMessages() {
      this.messages = [
        {
          id: 'msg-welcome',
          sender: 'ai',
          text: `👋 Hello! I'm your **PromoVista AI Marketing Co-Pilot**.\n\nI understand your active campaign strategy, brand voice, and target demographic. You can ask me to revise ads, adapt copy for WhatsApp, craft TikTok hooks, brainstorm hashtags, or optimize conversion rates.\n\nTry one of the quick prompts below or type your custom instruction!`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          quickActions: [
            "Make the advertisement more exciting",
            "Create a WhatsApp broadcast version",
            "Give me 5 viral hashtags",
            "Write a 3-part TikTok video script hook",
            "Suggest an urgent email subject line"
          ]
        }
      ];
    }

    async processUserMessage(userText) {
      const trimmed = userText.trim();
      if (!trimmed) return null;

      const userMsg = {
        id: 'usr-' + Date.now(),
        sender: 'user',
        text: trimmed,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      this.messages.push(userMsg);

      // Analyze intent based on current campaign context
      const aiResponse = this.generateResponse(trimmed);
      this.messages.push(aiResponse);

      return aiResponse;
    }

    generateResponse(prompt) {
      const lower = prompt.toLowerCase();
      const campaign = this.currentCampaign || {
        product: "FreshBite Cold Coffee",
        category: "Beverage",
        audience: "College Students",
        benefits: "Refreshing instant energy burst, sustained focus for study marathons",
        offer: "20% student discount",
        tone: "Young & Exciting",
        ad: {
          headline: "Beat the Heat. Sip the Energy.",
          body: "Crush mid-semester fatigue with the creamiest, ice-chilled brew in town. Slow-steeped for 16 hours with creamy velvety richness.",
          cta: "Grab Your 20% Student Discount Today!"
        }
      };

      const pName = campaign.product;
      const pAudience = campaign.audience;
      const pOffer = campaign.offer;

      // 1. "Make advertisement more exciting"
      if (lower.includes("exciting") || (lower.includes("make") && lower.includes("ad")) || lower.includes("more punchy") || lower.includes("hype")) {
        const revisedHeadline = `⚡ ZERO CRASH. 100% PURE FROST: MEET ${pName.toUpperCase()}! ❄️`;
        const revisedBody = `Stop letting 3 PM lectures suck your soul dry! ${pName} hits like an electric ice blast straight to your brain cells. Handcrafted, velvety, and dangerously delicious—this isn't just cold brew, it's straight-up cheat code energy for high achievers.`;
        const revisedCta = `🔥 Claim Your ${pOffer} Before The Campus Hub Sells Out! 🏃💨`;

        return {
          id: 'ai-' + Date.now(),
          sender: 'ai',
          text: `Here is a high-voltage, high-energy revision of your advertisement designed to maximize adrenaline and click-through rates:\n\n**HEADLINE:**\n"${revisedHeadline}"\n\n**BODY:**\n${revisedBody}\n\n**CALL TO ACTION:**\n"${revisedCta}"`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          appliable: {
            target: 'ad',
            data: {
              headline: revisedHeadline,
              body: revisedBody,
              cta: revisedCta
            },
            label: "Apply Revised Ad to Campaign Dashboard"
          }
        };
      }

      // 2. "Create WhatsApp version"
      if (lower.includes("whatsapp") || lower.includes("broadcast") || lower.includes("chat message")) {
        const waText = `Hey guys! ☕❄️ Quick heads up!\n\nIf you're stuck in the library or powering through assignments today, *${pName}* is serving up cold brews right now!\n\n🎁 *STUDENT EXCLUSIVE:* Get *${pOffer}* when you order today.\n\n✅ Triple-filtered cold extraction\n✅ Zero bitter crash\n✅ Instant pickup\n\n📲 Order in 15 seconds here:\n👉 https://order.${pName.toLowerCase().replace(/[^a-z0-9]/g, '')}.com?code=STUDENT20\n\nTag or forward to your study squad so they don't miss out! 🚀`;

        return {
          id: 'ai-' + Date.now(),
          sender: 'ai',
          text: `Here is a high-converting, mobile-optimized WhatsApp broadcast formatted with bold formatting and a direct CTA link:\n\n\`\`\`text\n${waText}\n\`\`\``,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          appliable: {
            target: 'social',
            data: {
              caption: waText,
              hashtags: ["#CampusSpecial", `#${pName.replace(/\s+/g, '')}`, "#WhatsAppOffer"]
            },
            label: "Update Social Card with WhatsApp Copy"
          }
        };
      }

      // 3. "Give me 5 hashtags"
      if (lower.includes("hashtag") || lower.includes("tag")) {
        const cleanName = pName.replace(/[^a-zA-Z0-9]/g, '');
        const hashtags = [
          `#${cleanName}`,
          `#${cleanName}Vibe`,
          `#StudyFuel2026`,
          `#CampusEssentials`,
          `#ColdBrewAddict`,
          `#BrainFuelDaily`,
          `#StudentLifeHacks`
        ];

        return {
          id: 'ai-' + Date.now(),
          sender: 'ai',
          text: `Here are 7 high-performing, hyper-relevant hashtags curated for **${pName}** on Instagram, TikTok, and Twitter:\n\n${hashtags.map((h, i) => `${i + 1}. **${h}** (High engagement & targeted reach)`).join('\n')}\n\n*Pro-tip:* Place the top 3 in your caption body and the rest in the first comment for maximum algorithmic reach!`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          appliable: {
            target: 'hashtags',
            data: hashtags,
            label: "Add These Hashtags to Social Post"
          }
        };
      }

      // 4. "TikTok hooks" / "Video scripts"
      if (lower.includes("tiktok") || lower.includes("reel") || lower.includes("video") || lower.includes("hook")) {
        return {
          id: 'ai-' + Date.now(),
          sender: 'ai',
          text: `Here are 3 viral short-form video hooks tailored for **${pName}**:\n\n**Hook 1 (Relatable Pain Point):**\n*"Tell me you're exhausted from midterms without telling me you're exhausted... (Cut to: Ice cubes dropping into frosty ${pName})"* 🧊\n\n**Hook 2 (Curiosity Gap):**\n*"Why is everyone in the campus library drinking this exact cup today? I investigated..."* 👀\n\n**Hook 3 (Money-Saving Hack):**\n*"Stop spending $7 at corporate cafes. Flash your student ID and get 20% off the smoothest cold brew on campus."* 💸\n\n*Sound recommendation:* Trending upbeat lofi or sped-up indie pop.`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        };
      }

      // 5. "Email subject line" / "Email blast"
      if (lower.includes("email") || lower.includes("newsletter") || lower.includes("subject line")) {
        return {
          id: 'ai-' + Date.now(),
          sender: 'ai',
          text: `Here is a high-open-rate email package for **${pName}**:\n\n**Subject Line A (Urgency):** ☕ Your 3 PM crash called. We solved it (20% off inside)\n**Subject Line B (Curiosity):** The library secret everyone is talking about...\n**Subject Line C (Direct Offer):** Flash Student Privilege: Grab ${pOffer} on ${pName}\n\n**Preview Text:** Smooth, ice-cold energy brewed for your biggest study sprint.\n\n**Core Body:**\nHi there,\nDeadlines don't wait, and neither should you. Before you resign yourself to burnt cafeteria coffee, drop by and taste the difference 16 hours of slow cold-steeping makes.\n\n[Claim Your Student 20% Off Here]`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        };
      }

      // 6. "Product description" / "E-commerce"
      if (lower.includes("description") || lower.includes("product") || lower.includes("rewrite")) {
        const enhancedOverview = `Experience pure refreshment with ${pName}. Specially crafted for ${pAudience}, every batch balances premium quality with unmatched satisfaction. Enjoy ${pOffer} today!`;
        return {
          id: 'ai-' + Date.now(),
          sender: 'ai',
          text: `Here is an optimized, conversion-focused product description for **${pName}**:\n\n**Product Title:** ${pName} — Reserve Edition\n**Overview:** ${enhancedOverview}\n**Key Value:** Sustained energy, refined flavor profile, zero harsh crashes.\n**Special Offer:** ${pOffer}`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          appliable: {
            target: 'description',
            data: {
              overview: enhancedOverview
            },
            label: "Update Product Description Card"
          }
        };
      }

      // 7. Generic marketing inquiry / Co-Pilot advice
      return {
        id: 'ai-' + Date.now(),
        sender: 'ai',
        text: `Based on your campaign strategy for **${pName}** targeting **${pAudience}**:\n\nTo maximize conversion on "${prompt}", I recommend aligning your key hook around **${campaign.benefits || "instant tangible results"}** while emphasizing your current promotion (**${pOffer}**).\n\nWould you like me to:\n1. 🎯 Draft a specific copy variation?\n2. 📱 Format this for a specific platform (Instagram, TikTok, WhatsApp, LinkedIn)?\n3. 💡 Run a conversion rate optimization critique on your current headline?`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        quickActions: [
          "Make the advertisement more exciting",
          "Create a WhatsApp broadcast version",
          "Give me 5 viral hashtags"
        ]
      };
    }
  }

  return MarketingChatAssistant;
});
